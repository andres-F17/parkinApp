package com.example.tutvideo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
