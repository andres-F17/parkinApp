# Hasanm08 Flutter Project [![Open in Visual Studio Code](https://open.vscode.dev/badges/open-in-vscode.svg)](https://open.vscode.dev/hasanm08/flutter)

Just a simple app. to have a release version message me
<p></p>
t.me/hasanm08
<p></p>
<p></p>

<p align="center">
  <img  src="threed_mockup (3).png">
</p>

<p align="center">
  <img  src="Screen2.png">
</p>
<p align="center">
  <img  src="Screen3.png">
</p>
