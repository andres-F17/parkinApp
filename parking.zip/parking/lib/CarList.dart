import 'package:flutter/material.dart';

class CarList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text("Car List Clicked")),
    );
  }
}
